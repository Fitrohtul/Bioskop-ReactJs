import { Card, Container, Row, Col, Image } from "react-bootstrap"
import duneImage from "../assets/images/trending/dilan.jpg"
import everythingImage from "../assets/images/trending/love for sale.jpg"
import infiniteImage from "../assets/images/trending/mariposa.jpg"
import jokerImage from "../assets/images/trending/bucin.jpg"
import lightyearImage from "../assets/images/trending/matt.jpg"
import morbiusImage from "../assets/images/trending/serigala.jpg"

const Trending = () => {
  return (
    <div>
      <Container>
        <br />
        <h1 className="text-white">BUCIN MOVIES</h1>
        <br />
        <Row>
          <Col md={4} className="movieWrapper" id="trending">
            <Card className="movieImage">
              <Image src={duneImage} alt="Dune Movies" className="images" />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
                  <Card.Title className="text-center">DILAN 1990</Card.Title>
                  <Card.Text className="text-left">
                  Dilan yang pintar, baik hati dan romantis. semua dengan caranya sendiri. Cara Dilan mendekati Milea tidak sama dengan teman-teman lelakinya yang lain, bahkan Beni, pacar Milea di Jakarta. Bahkan cara berbicara Dilan yang terdengar kaku, lambat laun justru membuat Milea kerap merindukannya jika sehari saja ia tak mendengar suara itu. Perjalanan hubungan mereka tak selalu mulus. Beni, gank motor, tawuran, Anhar, Kang Adi, semua mewarnai perjalanan itu. Dan Dilan dengan caranya sendiri selalu bisa membuat Milea percaya ia bisa tiba di tujuan dengan selamat. Tujuan dari perjalanan ini. Perjalanan mereka berdua. Katanya, dunia SMA adalah dunia paling indah. Dunia Milea dan Dilan satu tingkat lebih indah daripada itu.
                  </Card.Text>
                  <Card.Text className="text-left">
                    Tayang di bioskop
                  </Card.Text>
                </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image
                src={everythingImage}
                alt="Dune Movies"
                className="images"
              />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
                  <Card.Title className="text-center">
                    LOVE FOR SALE
                  </Card.Title>
                  <Card.Text className="text-left">
                  Sudah terlalu lama hidup sendiri, Richard telanjur nyaman menjalani hidupnya yang datar dan tanpa tantangan. Tetapi semua itu berubah ketika ia menemukan Arini melalui aplikasi Love, Inc. Pertemuannya dengan Arini seketika mengguncang dunia Richard. Ini bukan kisah cinta biasa, melainkan sebuah kisah pendewasaan diri seorang manusia urban yang unik.
                  </Card.Text>
                  <Card.Text className="text-left">
                    Tayang di youtube
                  </Card.Text>
                </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image src={infiniteImage} alt="Dune Movies" className="images" />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
                  <Card.Title className="text-center">MARIPOSA</Card.Title>
                  <Card.Text className="text-left">
                  Mariposa (Kupu-kupu) seperti kamu, aku mengejar tapi kamu menghindar. Acha bertekad ingin mendapatkan hati Iqbal, seorang cowok cakep, pintar dan dikenal berhati dingin. Sahabat Acha, AMANDA, berusaha mencegah niat Acha untuk mendekati Iqbal. Amanda takut Acha akan terluka dan sakit hati.
                  </Card.Text>
                  <Card.Text className="text-left">
                    Tayang di youtube
                  </Card.Text>
                </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image src={jokerImage} alt="Dune Movies" className="images" />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
                  <Card.Title className="text-center">BUCIN</Card.Title>
                  <Card.Text className="text-left">
                  Tujuan kursus ini adalah untuk mengajarkan cara memiliki hubungan yang sehat dan tidak hanya menguntungkan satu pihak. Kursus ini dibuat oleh Vania, seorang lulusan S2 psikologi dengan spesialisasi cinta. Ternyata metode yang digunakan oleh Vania tidak konvensional dan lumayan ekstrim, dia menggunakan konsep ESCAPE ROOM untuk menjelaskan konsep cinta. Sering kali mereka ingin berhenti karena tidak sanggup.
                  </Card.Text>
                  <Card.Text className="text-left">
                    Tayang di youtube
                  </Card.Text>
                </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image
                src={lightyearImage}
                alt="Dune Movies"
                className="images"
              />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
                  <Card.Title className="text-center">MATT & MOU</Card.Title>
                  <Card.Text className="text-left">
                  dua sahabat yang sudah berteman sejak kecil. Sifat mereka saling bertolak belakang. Matt bersikap sangat protektif terhadap Mou, bahkan termasuk dalam memilih pacar.
                  </Card.Text>
                  <Card.Text className="text-left">
                    Tayang di youtube
                  </Card.Text>
                </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image src={morbiusImage} alt="Dune Movies" className="images" />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
                  <Card.Title className="text-center">SERIGALA BUCIN</Card.Title>
                  <Card.Text className="text-left">
                  Dylan, anak SMA yang dibalik ketampanannya ternyata punya pribadi yang tengil dan kocak. Sayangnya, meski hidupnya terlihat nyaris sempurna, Dylan mengalami kejadian luar biasa yang tak bisa ia ungkap kepada siapapun. Bahkan kini tetap saja ada yang tidak suka dengan kehadiran Dylan.
                  </Card.Text>
                  <Card.Text className="text-left">
                    Tayang di bioskop
                  </Card.Text>
                </div>
              </div>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  )
}

export default Trending
