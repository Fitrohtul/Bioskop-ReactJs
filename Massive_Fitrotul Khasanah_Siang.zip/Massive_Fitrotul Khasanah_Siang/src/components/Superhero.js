import { Card, Container, Row, Col, Image } from "react-bootstrap"
import antmanImage from "../assets/images/superhero/doll.jpg"
import avengerImage from "../assets/images/superhero/jalangkung.jpg"
import batmanImage from "../assets/images/superhero/takut.jpg"
import robinhoodImage from "../assets/images/superhero/sajen.jpg"
import spidermanImage from "../assets/images/superhero/kkn.jpg"
import supermanImage from "../assets/images/superhero/ghost.jpg"

const SuperHero = () => {
  return (
    <div>
      <Container>
        <br />
        <h1 className="text-white">HOROR MOVIES</h1>
        <br />
        <Row>
          <Col md={4} className="movieWrapper" id="superhero">
            <Card className="movieImage">
              <Image src={antmanImage} alt="Dune Movies" className="images" />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
                  <Card.Title className="text-center">SPIRIT DOLL</Card.Title>
                  <Card.Text className="text-left">
                   Spirit Doll adalah film horor yang menceritakan seorang gadis bernama Dara yang mengalami teror karena boneka arwah miliknya.
                  </Card.Text>
                  <Card.Text className="text-left">
                    Tayang di bioskop
                  </Card.Text>
                </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image src={avengerImage} alt="Dune Movies" className="images" />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
                  <Card.Title className="text-center">JALANGKUNG SANDEKALA</Card.Title>
                  <Card.Text className="text-left">
                  Perjalanan liburan satu keluarga kecil ke luar kota menjadi petaka ketika mereka membuat tur ke sebuah area danau wisata. Di sinilah anak paling kecil yang bernama Kinan (Muzakki Ramdhan), tiba-tiba menghilang tanpa jejak secara misterius saat matahari terbenam.
                  </Card.Text>
                  <Card.Text className="text-left">
                    Tayang di bioskop
                  </Card.Text>
                </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image src={batmanImage} alt="Dune Movies" className="images" />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
                  <Card.Title className="text-center">TAKUT</Card.Title>
                  <Card.Text className="text-left">
                  Yudha yang bermasalah dengan paru-parunya, pindah ke vila Andaru di daerah pegunungan untuk rehab. Tetapi semenjak pindah ke Vila Andaru kehidupan Yudha berubah menjadi sangat mengerikan. Keanehan-keanehan kerap ia temui. Elisa dan Dewa adalah dua orang siswa yang tengah mencari kakak Elisa (Erlita) yang hilang.
                  </Card.Text>
                  <Card.Text className="text-left">
                    Diangkat dari Novel
                  </Card.Text>
                </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image
                src={robinhoodImage}
                alt="Dune Movies"
                className="images"
              />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
                  <Card.Title className="text-center">SAJEN</Card.Title>
                  <Card.Text className="text-left">
                  Adanya tiga sajen di SMA Pelita Bangsa adalah sebuah misteri. Desas-desus mengatakan sajen tersebut merupakan upaya sekolah menenangkan arwah siswa yang bunuh diri karena menjadi korban bullying.
                  </Card.Text>
                  <Card.Text className="text-left">
                    Telah rilis
                  </Card.Text>
                </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image
                src={spidermanImage}
                alt="Dune Movies"
                className="images"
              />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
                  <Card.Title className="text-center">KKN DI DESA PENARI</Card.Title>
                  <Card.Text className="text-left">
                  cerita ini diambil dari sebuah kisah nyata sekelompok mahasiswa yang tengah melakukan program KKN (Kuliah Kerja Nyata) di Desa Penari. Tak berjalan mulus, serentetan pengalaman horror pun menghantui mereka hingga program KKN tersebut berakhir tragis.
                  </Card.Text>
                  <Card.Text className="text-left">
                    Tayang di bioskop
                  </Card.Text>
                </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image src={supermanImage} alt="Dune Movies" className="images" />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
                  <Card.Title className="text-center">GHOST 2 WRITER</Card.Title>
                  <Card.Text className="text-left">
                  Hal ini membuat Naya sebal dan enggan berurusan dengan dunia perhantuan lagi. Namun semua berubah saat calon suaminya Vino tiba-tiba meninggal.
                  </Card.Text>
                  <Card.Text className="text-left">
                    Diangka dari Novel
                  </Card.Text>
                </div>
              </div>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  )
}

export default SuperHero
